This repository will have the code (including examples) needed to use Tensorflow Lite Micro on an Arduino.

